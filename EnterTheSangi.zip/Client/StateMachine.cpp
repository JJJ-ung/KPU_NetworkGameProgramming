//#include "framework.h"
//#include "StateMachine.h"
//
//StateMachine::StateMachine(LPDIRECT3DDEVICE9 pGraphic_Device)
//	:Component(pGraphic_Device)
//{
//}
//
//StateMachine::~StateMachine()
//{
//}
//
//HRESULT StateMachine::Ready_Component()
//{
//	return Component::Ready_Component();
//}
//
//INT StateMachine::Update_Component(float time_delta)
//{
//	return Component::Update_Component(time_delta);
//}
//
//INT StateMachine::LateUpdate_Component(float time_delta)
//{
//	return Component::LateUpdate_Component(time_delta);
//}
//
//HRESULT StateMachine::Render_Component()
//{
//	return Component::Render_Component();
//}
//
//void StateMachine::Free()
//{
//	Component::Free();
//}
